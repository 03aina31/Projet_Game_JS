$(window).ready(function(){
    $("#logo").css({
        "top":"0"
    });
    $(".bar").css({
        "bottom":"0"
    });
    $('.bordg').css({
        "left":"0"
    });
    $('.bordd').css({
        "left":"100%"
    });
    $('i').css({
        "opacity":"1"
    });
    
});
