import { _attend } from './fonctions.js';
import {Pion, De, COULEURS, RAYON_PIONS as R_PIONS, COORD_MAP as Map, THEMES} from './elements.js';

$('#btr').mouseenter(function(){
    $('#btr').css("background-color","black");
});
$('#btr').mouseout(function(){
    $('#btr').css("background-color","rgb(240, 116, 33)");
});

var timer=document.getElementById('timer');

function efface(k){
    for(let i=0;i<4;i++){
      if(document.getElementById('bt'+i).textContent!=THEMES.divertissement.reponse[k][0]){
        $('#bt'+i).hide();
      }
    }
}

function verifie(bt,k){
    if(document.getElementById(bt).textContent==THEMES.divertissement.reponse[k][0]){
        console.log("Bonne reponse");
    } 
    else console.log("Mauvaise reponse");
}

function chrono(k){
    var i=6;
    var t=0;
    let to = setInterval(()=>{

        $('#bt0').click(function(){

            verifie('bt0',k);
            t=parseInt(i+1);
            efface(k);
        }); 
        $('#bt1').click(function(){
            
            verifie('bt1',k);
            t=parseInt(i+1);
            efface(k);
        }); 
        $('#bt2').click(function(){
            
            verifie('bt2',k);
            t=parseInt(i+1);
            efface(k);
        }); 
        $('#bt3').click(function(){
            verifie('bt3',k);
            t=parseInt(i+1);
            efface(k);
        });

        if(t!=0){
            console.log(t);
            i++;
            clearInterval(to);
        }

        timer.innerHTML = i--;
        if(i == -1) {
            t=0;
            clearInterval(to);
            efface(k);
        }
    },1000);   
    return t;    
} 

/*function _attend(duree){
    const t =Date.now();
    while(Date.now()-t<duree){}
}


function _chrono(){

    for(let i=6;i>=0;i--){
        _attend(1000);
        timer.innerHTML = i;
        console.log(i);
    }
} */

//_chrono();

function different(tab,j){
    let i=0;
    let egal=0;
    do{
        if(tab[i]==j){
            egal=1;
            break;
        } 
        else i++;
    }while(i<4);
    return egal;
}


$('#btr').click(function(){
    $("#nuage").css("transform","translateY(0)");
    $("#conteneur").css({
        transform:"translateX(0)",
        backgroundColor: "rgba(244, 244, 244, 0.489)",
    })

    let theme = "loisir"
    switch(theme){
        case "divertissement":{
            //alert('A')
            //document.querySelector('#nuage').style.background = 'url("../Images/bleu.png")'
           $('#nuage').css({
                background:'url("../Images/bleu.png")',
                backgroundSize: '50%',
                backgroundPosition:'top',
                backgroundRepeat: 'no-repeat'
            })
        }
        case "loisir":{
            $('#nuage').css({
                background:'url("../Images/jaune.png")',
                backgroundSize: '50%',
                backgroundPosition:'top',
                backgroundRepeat: 'no-repeat'
            })
        }
    }

    var k = Math.floor((Math.random())*6);
    $('#qst').text(THEMES.divertissement.question[k]);
    /*let tps = 7;

    let tps_de_reflexion = setInterval(function(){
        tps--;
        timer.innerHTML = tps;
    },1000)

    _attend(6000);*/
    chrono(k);

    for(let i=0;i<4;i++){
        if(i==0){
            var j=Math.floor((Math.random())*4);
            var lj=[];
            lj[i]=j;
            $('#bt'+i).text(THEMES.divertissement.reponse[k][j]);
        }
        else{
            do{
                j=Math.floor((Math.random())*4);
            }while(different(lj,j));
            lj[i]=j;
            $('#bt'+i).text(THEMES.divertissement.reponse[k][j]);
        }
    }
    $(this).hide();
});